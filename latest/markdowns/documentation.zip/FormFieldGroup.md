# FormFieldGroup


This is a helper component that is used by most of the custom form
components. Perfect if you need to wrap a complex group of form fields
(Play with the different properties inside the code editor
to see how they affect the overall look and feel). The first example
sets the `layout to inline` and sets the `vAlign to middle` and `small rowSpacing`

```js
---
type: example
---
  <FormFieldGroup
    description="Breakfast"
    rowSpacing="small"
    layout="inline"
    vAlign="middle"
  >
    <TextInput renderLabel="Favorite Breakfast Eatery"
      messages={[
      { text: 'Invalid name', type: 'newError' }
      ]}
    />
    <TextInput renderLabel="Favorite Side Dish" />
    <RadioInputGroup
      name="beverage"
      description="Beverage of Choice"
      defaultValue="coffee"
      layout="columns"
    >
      <RadioInput label="Juice" value="juice" />
      <RadioInput label="Water" value="water" />
      <RadioInput label="Coffee" value="coffee" />
      <RadioInput label="Milk" value="milk" />
      <RadioInput label="Soda" value="soda" />
      <RadioInput label="Hot Tea" value="tea" />
    </RadioInputGroup>
  </FormFieldGroup>
```

This example sets the `layout to columns` and sets the `vAlign to top`
and the `colSpacing to medium`

```js
---
type: example
---
  <FormFieldGroup
    description="Lunch"
    colSpacing="medium"
    layout="columns"
    vAlign="top"
  >
    <TextInput renderLabel="Dining Style" />
    <TextInput renderLabel="Favorite Lunch Outing"/>
    <CheckboxGroup name="times"
      layout="stacked"
      onChange={function (value) { console.log(value) }}
      defaultValue={['afternoon']}
      description="Best Time to Head Out for Lunch"
    >
      <Checkbox label="Between 11:00 and 11:30" value="morning" />
      <Checkbox label="Between 11:30 and Noon" value="early-afternoon" />
      <Checkbox label="Between Noon and 1:00" value="afternoon" />
      <Checkbox label="Between 1:00 and 2:00" value="late-afternoon" />
    </CheckboxGroup>
  </FormFieldGroup>
```

This example sets the `layout to stacked` and sets the `rowSpacing to large`

```js
---
type: example
---
  <FormFieldGroup
    description="Dinner"
    layout="stacked"
    rowSpacing="large"
    messages={[
    { text: 'Complete All Fields', type: 'newError' }
    ]}
  >
    <RadioInputGroup
      name="diningstyle"
      description="Size of Your Meal"
      defaultValue="grill"
      layout="stacked"
    >
      <RadioInput label="Keep it light" value="light" />
      <RadioInput label="Anything cooked on the grill" value="grill" />
      <RadioInput label="Bring it on... Ready for the full course" value="full-course" />
      <RadioInput label="Breakfast for dinner" value="breakfast" />
    </RadioInputGroup>
    <TextInput renderLabel="If Not At Home - I'd Like To Eat Dinner At"
      />
    <Checkbox label="Love to Eat Dessert After Dinner" value="medium" variant="toggle" />
  </FormFieldGroup>
```

### Required Fields

Whenever a `FormFieldGroup` contains required fields, you must include a note explaining what the asterisk means — typically "Fields marked with an asterisk (\*) are required."

```js
---
type: example
---
<FormFieldGroup
  description="Contact Information"
  rowSpacing="small"
  layout="stacked"
>
  <Text>Fields marked with an asterisk <span aria-hidden="true">(*)</span> are required.</Text>
  <TextInput renderLabel="Full Name" isRequired />
  <TextInput renderLabel="Email Address" isRequired />
  <TextInput renderLabel="Phone Number" />
</FormFieldGroup>
```

### Guidelines

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="a11y" title="Accessibility">
    <Figure.Item>Avoid placeholder text (it creates usability problems by increasing cognitive load, low contrast, lack of screen reader compatibility, etc.)</Figure.Item>
  </Figure>
</Guidelines>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| FormFieldGroup | description | `React.ReactNode` | Yes | - |  |
| FormFieldGroup | as | `AsElementType` | No | `'fieldset'` | the element type to render as |
| FormFieldGroup | messages | `FormMessage[]` | No | - | Array of objects with shape: `{ text: React.ReactNode, type: One of: ['newError', 'error', 'hint', 'success', 'screenreader-only'] }` |
| FormFieldGroup | messagesId | `string` | No | - | id for the form field messages |
| FormFieldGroup | disabled | `boolean` | No | `false` |  |
| FormFieldGroup | children | `React.ReactNode` | No | - |  |
| FormFieldGroup | layout | `'stacked' \| 'columns' \| 'inline'` | No | - |  |
| FormFieldGroup | rowSpacing | `'none' \| 'small' \| 'medium' \| 'large'` | No | `'medium'` |  |
| FormFieldGroup | colSpacing | `'none' \| 'small' \| 'medium' \| 'large'` | No | `'small'` |  |
| FormFieldGroup | vAlign | `'top' \| 'middle' \| 'bottom'` | No | `'middle'` |  |
| FormFieldGroup | startAt | `'small' \| 'medium' \| 'large' \| 'x-large' \| null` | No | - |  |
| FormFieldGroup | elementRef | `(element: Element \| null) => void` | No | - | provides a reference to the underlying html root element |
| FormFieldGroup | isGroup | `` | No | `true` |  |

### Usage

Install the package:

```shell
npm install @instructure/ui-form-field
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { FormFieldGroup } from '@instructure/ui-form-field'
```

