# Badge


### Making badges accessible

Badge counts are automatically fed to screenreaders through the `aria-describedby`
attribute. Often a stand alone number doesn't give a screenreader user enough context (_"3" vs. "You have 3 unread emails"_).
The examples below use the `formatOutput` prop to make the badge more screenreader-friendly.

```js
---
type: example
---
  <div>
    <Badge
      count={99}
      pulse
      margin="0 general.spaceXl 0 0"
      formatOutput={function (formattedCount) {
        return (
          <AccessibleContent alt={`You have ${formattedCount} new edits to review`}>
            {formattedCount}
          </AccessibleContent>
        )
      }}
    >
      <IconButton
        renderIcon={<UserRoundInstUIIcon />}
        screenReaderLabel="Edits"
        withBorder={false}
        withBackground={false}
      />
    </Badge>
    <Badge
      type="notification"
      formatOutput={function () {
        return <ScreenReaderContent>You have new edits to review</ScreenReaderContent>
      }}
    >
      <IconButton
        renderIcon={<UserRoundInstUIIcon />}
        screenReaderLabel="Edits"
        withBorder={false}
        withBackground={false}
      />
    </Badge>
  </div>
```

> Note the use of the `pulse` prop in the first example to make the Badge slowly pulse twice on mount.

### Limit the count

Use the `countUntil` prop to set a limit for the count. The default for `formatOverflowText` is a "+" symbol.

```js
---
type: example
---
<div>
  <Badge count={105} countUntil={100} margin="0 general.spaceXl 0 0">
    <Button>Inbox</Button>
  </Badge>
  <Badge count={250} countUntil={100}>
    <Button>Assignments</Button>
  </Badge>
</div>
```

### Standalone, notification and color variants

Setting the `standalone` prop to `true` renders Badge as a standalone
element that is not positioned relative to a child and displays inline-block.
Setting `type="notification"` will render small circles that should not contain any visible text.

```js
---
type: example
---
<div>
  <Flex padding='general.spaceMd' display='inline-flex' alignItems="center">
    <Badge standalone count={6} margin='0 general.spaceMd 0 0' />
    <Badge
      type="notification"
      standalone
      formatOutput={function () {
        return <ScreenReaderContent>This is a notification</ScreenReaderContent>
      }}
    />
  </Flex>
  <Flex padding='general.spaceMd' display='inline-flex' alignItems="center">
    <Badge standalone variant="success" count={12} margin='0 general.spaceMd 0 0' />
    <Badge
      variant="success"
      type="notification"
      standalone
      formatOutput={function () {
        return <ScreenReaderContent>This is a success notification</ScreenReaderContent>
      }}
    />
  </Flex>
  <Flex padding='general.spaceMd' display='inline-flex' alignItems="center">
    <Badge standalone variant="danger" count={18} countUntil={10} margin='0 general.spaceMd 0 0' />
    <Badge
      variant="danger"
      type="notification"
      standalone
      formatOutput={function () {
        return <ScreenReaderContent>This is a danger notification</ScreenReaderContent>
      }}
    />
  </Flex>
  <View display='inline-flex' background='primary-inverse'>
    <Flex padding='general.spaceMd' display='inline-flex' alignItems="center" background='primary-inverse'>
      <Badge standalone variant="inverse" count={8} margin='0 general.spaceMd 0 0' />
      <Badge
        variant="inverse"
        type="notification"
        standalone
        formatOutput={function () {
          return <ScreenReaderContent>This is a danger notification</ScreenReaderContent>
        }}
      />
    </Flex>
  </View>
</div>
```

### Placement

Default is `top end`. **Note that standalone badges can't be placed.**

```js
---
type: example
---
const EditButton = () => (
  <IconButton
    renderIcon={<UserRoundInstUIIcon />}
    screenReaderLabel="Edit page"
    withBorder={false}
    withBackground={false}
  />
)

const Example = () => (
  <div>
    <View as="div" margin="0 0 general.spaceXl">
      <Badge count={21} margin="0 general.space2xl 0 0" placement="top start">
        <EditButton />
      </Badge>
      <Badge count={21} margin="0 general.space2xl 0 0">
        <EditButton />
      </Badge>
      <Badge count={21} margin="0 general.space2xl 0 0" placement="bottom start">
        <EditButton />
      </Badge>
      <Badge count={21} margin="0 general.space2xl 0 0" placement="bottom end">
        <EditButton />
      </Badge>
      <Badge count={21} margin="0 general.space2xl 0 0" placement="start center">
        <EditButton />
      </Badge>
      <Badge count={21} placement="end center">
        <EditButton />
      </Badge>
    </View>
    <View as="div">
      <Badge
        type="notification"
        margin="0 general.space2xl 0 0"
        placement="top start"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
      <Badge
        type="notification"
        margin="0 general.space2xl 0 0"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
      <Badge
        type="notification"
        margin="0 general.space2xl 0 0"
        placement="bottom start"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
      <Badge
        type="notification"
        margin="0 general.space2xl 0 0"
        placement="bottom end"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
      <Badge
        type="notification"
        margin="0 general.space2xl 0 0"
        placement="start center"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
      <Badge
        type="notification"
        placement="end center"
        formatOutput={function () {
          return (
            <ScreenReaderContent>
              Updates are available for your account
            </ScreenReaderContent>
          )
        }}
      >
        <EditButton />
      </Badge>
    </View>
  </div>
)

render(<Example />)
```

### Guidelines

```js
---
type: embed
---
<Guidelines>
  <Figure recommendation="yes" title="Do">
    <Figure.Item>Use count for up to 2 digits of numbers</Figure.Item>
    <Figure.Item>Use "+" symbol for more than 2 digits (99+)</Figure.Item>
    <Figure.Item>Use for numeric count (like unread messages)</Figure.Item>
    <Figure.Item>Provide accessible text for what the number represents</Figure.Item>
  </Figure>
  <Figure recommendation="no" title="Don't">
    <Figure.Item>Use as a status indicator refer to Pill</Figure.Item>
    <Figure.Item>Use for text strings</Figure.Item>
  </Figure>
</Guidelines>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| Badge | count | `number` | No | - |  |
| Badge | countUntil | `number` | No | - | The number at which the count gets truncated by formatOverflowText. For example, a countUntil of 100 would stop the count at 99. |
| Badge | type | `'count' \| 'notification'` | No | `'count'` | Render Badge as a counter (`count`) or as a smaller dot (`notification`) with no count number displayed. |
| Badge | standalone | `boolean` | No | `false` | Render Badge as an inline html element that is not positioned relative to a child. |
| Badge | pulse | `boolean` | No | `false` | Make the Badge slowly pulse twice to get the user's attention. |
| Badge | variant | `'primary' \| 'success' \| 'danger' \| 'inverse'` | No | `'primary'` |  |
| Badge | elementRef | `(element: Element \| null) => void` | No | `() => {}` | provides a reference to the underlying html root element |
| Badge | formatOverflowText | `(count: number, countUntil: number) => string` | No | `(_count: number, countUntil: number) =>
`${countUntil - 1} +`` |  |
| Badge | formatOutput | `(formattedCount: string) => React.JSX.Element \| string \| number` | No | - |  |
| Badge | as | `AsElementType` | No | - |  |
| Badge | display | `'inline-block' \| 'block'` | No | `'inline-block'` | Specifies the display property of the container. __Use "block" only when the content inside the Badge also has "block" display.__ |
| Badge | margin | `Spacing` | No | - | Valid values are `0`, `none`, `auto`, and Spacing token values, see https://instructure.design/layout-spacing. Apply these values via familiar CSS-like shorthand. For example, `margin="general.spaceMd auto"`. |
| Badge | placement | `PlacementPropValues` | No | `'top end'` | Supported values are `top start`, `top end`, `end center`, `bottom end`, `bottom start`, and `start center` |

### Usage

Install the package:

```shell
npm install @instructure/ui-badge
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { Badge } from '@instructure/ui-badge/v11_7'
```

