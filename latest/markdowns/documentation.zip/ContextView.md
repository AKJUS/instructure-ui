# ContextView


`<ContextView/>` is a container that can be rendered inline in the document flow (vs as a [Popover](#Popover)) but with an arrow pointing to something. See [RangeInput](#RangeInput) for an example of how ContextView can be used to display contextual information in conjunction with another component. It is used internally in [Popover](#Popover).

- Defaults to no padding around its content. To add padding, use the `padding` prop.

- Use the `textAlign` prop to change the alignment of the text inside `<ContextView />`.

- In use cases where `<ContextView/>` is not absolutely positioned, use the `margin` prop to set margin around the component.

```js
---
type: example
---
<div>
  <ContextView
    padding="small"
    margin="large"
    placement="end top"
    shadow="resting"
  >
    <Heading level="h3">Hello World</Heading>
  </ContextView>
  <ContextView
    margin="0 large 0 0"
    padding="small"
    placement="top"
  >
    <Heading level="h3">Hello World</Heading>
    <Text size="small">Some informational text that is helpful</Text>
  </ContextView>
  <ContextView
    margin="0 large 0 0"
    padding="small"
    textAlign="end"
    placement="start"
  >
    <Heading level="h3">Hello World</Heading>
    <Text size="small">This ContextView is end-text-aligned</Text>
  </ContextView>
  <ContextView
    placement="end bottom"
    padding="medium"
    background="inverse"
    width="30rem"
    margin="x-large 0 0"
  >
    <Text size="small">
      This ContextView uses the inverse background and medium padding. Its width prop is set to `30rem`, which causes long strings like this to wrap. It also has top margin to separate it from the ContextViews above it.
    </Text>
  </ContextView>
</div>
```


### Props

| Component | Prop | Type | Required | Default | Description |
|-----------|------|------|----------|---------|-------------|
| ContextView | as | `keyof JSX.IntrinsicElements \| ComponentType<P>` | No | `'span'` |  |
| ContextView | elementRef | `(element: Element \| null) => void` | No | `() => {}` |  |
| ContextView | height | `string \| number` | No | `'auto'` |  |
| ContextView | width | `string \| number` | No | `'auto'` |  |
| ContextView | maxHeight | `string \| number` | No | - |  |
| ContextView | maxWidth | `string \| number` | No | - |  |
| ContextView | minHeight | `string \| number` | No | - |  |
| ContextView | minWidth | `string \| number` | No | - |  |
| ContextView | children | `React.ReactNode` | No | `null` |  |
| ContextView | textAlign | `'start' \| 'center' \| 'end'` | No | `'start'` |  |
| ContextView | background | `'default' \| 'inverse'` | No | `'default'` |  |
| ContextView | debug | `boolean` | No | `false` |  |
| ContextView | margin | `Spacing` | No | - |  |
| ContextView | padding | `Spacing` | No | - |  |
| ContextView | shadow | `Shadow` | No | `'resting'` |  |
| ContextView | stacking | `Stacking` | No | - |  |
| ContextView | placement | `PlacementPropValues` | No | `'center end'` |  |
| ContextView | borderColor | `string` | No | - |  |

### Usage

Install the package:

```shell
npm install @instructure/ui-view
```

Import the component:

```javascript
/*** ES Modules (with tree shaking) ***/
import { ContextView } from '@instructure/ui-view'
```

